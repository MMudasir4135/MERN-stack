import "./App.css";
import About from "./components/About";
import Navbar from "./components/Navbar";
import TextForm from "./components/TextForm";
import React, { useState } from "react";
import Alert from "./components/Alert";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

function App() {
  const [mode, setMode] = useState("light");
  const [text, setText] = useState("Enable Dark Mode");
  const [alert, setAlert] = useState(null);

  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type,
    });
    setTimeout(() => {
      setAlert(null);
    }, 1000);
  };

  // demo

  var string = "Some Text";
  var string_length = string.split("").length;
  console.log(string_length);

  const toggelMode = () => {
    if (mode === "light") {
      setMode("dark");
      document.body.style.backgroundColor = "rgb(36 55 84)";
      setText("Enable Light Mode");
      showAlert("Dark mode has been enabled", "success");
      document.title = "TextUtils - Dark mode";
      setInterval(() => {
        document.title = "TextUtils is amazing";
      }, 2000);
      setInterval(() => {
        document.title = "Install TextUtils Now";
      }, 1500);
    } else {
      setMode("light");
      document.body.style.backgroundColor = "white";
      setText("Enable Dark Mode");
      showAlert("Light mode has been enabled", "success");
      document.title = "TextUtils - Light mode";
      setInterval(() => {
        document.title = "TextUtils is amazing";
      }, 2000);
      setInterval(() => {
        document.title = "Install TextUtils Now";
      }, 1500);
    }
  };

  return (
    <>
      {/* component routing 
    /home --> component 1
    /about --> component 2 */}
      <Router>
        <Navbar
          title="Demo"
          aboutText="About Us"
          mode={mode}
          text={text}
          toggelMode={toggelMode}
        />
        <Alert alert={alert} />
        <div className="container my-3">
          <Routes>
            <Route
              index
              path=""
              element={
                <TextForm
                  heading="Enter the text to analyze"
                  showAlert={showAlert}
                  mode={mode}
                />
              }
            />
            <Route
              exact
              path="/about"
              element={<About mode={mode} toggelMode={toggelMode} />}
            />
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;
