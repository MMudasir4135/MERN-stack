import ui from "./module1.mjs";

console.log(ui);