const a = "Harry";
const b = "Asim";
const c = "Mudasir";

export default {a,b,c};