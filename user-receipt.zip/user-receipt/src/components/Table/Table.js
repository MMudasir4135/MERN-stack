import React, { Fragment, useState } from "react";
import EditableRow from "../EditableRow/EditableRow";
import ReadOnlyRow from "../ReadOnlyRow/ReadOnlyRow";
import  '../Table/Table.css';

export default function Table(props) {

  // function to edit the user
  const handleEditClick = (event, detail) => {
    event.preventDefault();
    props.setEditUserId(detail.id);
    const formValues = {
      firstName: detail.firstName,
      surName: detail.surName,
      phoneNumber: detail.phoneNumber,
      country: detail.country,
      bankAccount: detail.bankAccount,
      serviceName: detail.serviceName,
      serviceType: detail.serviceType,
      amount: detail.amount,
    };
    setEditFormData(formValues);
  };

  // useState to initialize the editing of user detail
  const [editFormData, setEditFormData] = useState({
    firstName: "",
    surName: "",
    phoneNumber: "",
    country: "",
    bankAccount: "",
    serviceName: "",
    serviceType: "",
    amount: "",
  });

  // functon to save the edited user detail
  const handleEditFormChange = (event) => {
    event.preventDefault();
    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;
    const NewFormData = { ...editFormData };
    NewFormData[fieldName] = fieldValue;
    setEditFormData(NewFormData);
  };

  // function to add the edited user detail in the table
  const handleEditFormSubmit = (event) => {
    event.preventDefault();
    const editedDetail = {
      id: props.editUserId,
      firstName: editFormData.firstName,
      surName: editFormData.surName,
      phoneNumber: editFormData.phoneNumber,
      country: editFormData.country,
      bankAccount: editFormData.bankAccount,
      serviceName: editFormData.serviceName,
      serviceType: editFormData.serviceType,
      amount: editFormData.amount,
    };
    const newDetails = [...props.details];
    const index = props.details.findIndex(
      (detail) => detail.id === props.editUserId
    );
    newDetails[index] = editedDetail;
    props.setDetails(newDetails);
    props.setEditUserId(null);
  };

  // function to cancel editing the user detail
  const handleCancelClick = () => {
    props.setEditUserId(null);
  };

  // function to delete the user from table
  const handleDeleteClick = (userId) => {
    const newDetails = [...props.details];
    const index = props.details.findIndex((detail) => detail.id === userId);
    newDetails.splice(index, 1);
    props.setDetails(newDetails);
  };
  return (
    <>
      {/* table to show details */}
      <div className="container">
        <form onSubmit={handleEditFormSubmit}>
          <table>
            <thead>
              <tr>
                <th>First Name</th>
                <th>Surname</th>
                <th>Phone Number</th>
                <th>Country</th>
                <th>Bank Account</th>
                <th>Service Name</th>
                <th>Service Type</th>
                <th>Amount</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {props.details.map((detail) => (
                <Fragment>
                  {props.editUserId === detail.id ? (
                    <EditableRow
                      editFormData={editFormData}
                      handleEditFormChange={handleEditFormChange}
                      handleCancelClick={handleCancelClick}
                    />
                  ) : (
                    <ReadOnlyRow
                      detail={detail}
                      handleEditClick={handleEditClick}
                      handleDeleteClick={handleDeleteClick}
                    />
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </form>
      </div>
    </>
  );
}
