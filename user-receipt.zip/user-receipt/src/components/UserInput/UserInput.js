import React, { useState } from "react";
import { nanoid } from "nanoid";
import ".//UserInput.css";
import Table from "../Table/Table";

export default function UserInput() {
  // useState to get data from json file
  const [details, setDetails] = useState([]);

  // function trigerred on form submit to map on the table setting the value
  // for above useState and show values and clear the input fields
  const handleAddFormSubmit = (event) => {
    event.preventDefault();
    const newDetail = {
      id: nanoid(),
      firstName: addFormData.firstName,
      surName: addFormData.surName,
      phoneNumber: addFormData.phoneNumber,
      country: addFormData.country,
      bankAccount: addFormData.bankAccount,
      serviceName: addFormData.serviceName,
      serviceType: addFormData.serviceType,
      amount: addFormData.amount,
    };
    const newDetails = [...details, newDetail];
    setDetails(newDetails);
    event.target.reset();
  };

  // useState to map and get data from input fields
  const [addFormData, setAddFormData] = useState({
    firstName: "",
    surName: "",
    phoneNumber: "",
    country: "",
    bankAccount: "",
    serviceName: "",
    serviceType: "",
    amount: "",
  });

  // function to get values from input fields and assign them into a variable of above useState
  const handleAddFormChange = (event) => {
    event.preventDefault();
    const fieldName = event.target.getAttribute("name");
    const fieldvalue = event.target.value;
    const newFormData = { ...addFormData };
    newFormData[fieldName] = fieldvalue;
    setAddFormData(newFormData);
  };

  // function to open the pop-up form
  const openForm = () => {
    document.getElementById("myForm").style.display = "block";
  };

  // function to close the pop-up form
  const closeForm = () => {
    document.getElementById("myForm").style.display = "none";
  };

  const [editUserId, setEditUserId] = useState(null);

  return (
    <>
      <form onSubmit={handleAddFormSubmit}>
        {/* input to get user details */}
        <div className="conatainer">
          <h1>User Info</h1>
          <input
            className="input"
            type="text"
            id="fname"
            placeholder="First name"
            name="firstName"
            onChange={handleAddFormChange}
          ></input>
          <input
            className="input"
            type="text"
            id="Sname"
            placeholder="Surname"
            name="surName"
            onChange={handleAddFormChange}
          />
          <input
            className="input"
            type="number"
            id="phone"
            placeholder="Phone or mobile number"
            name="phoneNumber"
            onChange={handleAddFormChange}
          />
          <input
            className="input"
            type="text"
            id="Country"
            placeholder="Country"
            name="country"
            onChange={handleAddFormChange}
          />
          <input
            className="input"
            type="text"
            id="bank"
            placeholder="Back Account"
            name="bankAccount"
            onChange={handleAddFormChange}
          />
        </div>

        {/* pop-up form */}
        <div className="form-popup" id="myForm">
          <div className="form-container">
            <h1>Service Form</h1>

            {/* pop-up form inputs to get user details */}
            <input
              className="input"
              type="text"
              placeholder="Service name"
              name="serviceName"
              id="service"
              onChange={handleAddFormChange}
            />
            <input
              className="input"
              type="text"
              placeholder="type"
              name="serviceType"
              id="type"
              onChange={handleAddFormChange}
            />
            <input
              className="input"
              type="number"
              placeholder="Amount"
              name="amount"
              id="amount"
              onChange={handleAddFormChange}
            />
            <br />

            {/* button to submit pop-up form */}
            <button
              id="button"
              type="submit"
              className="btn submit"
              onClick={closeForm}
            >
              Submit
            </button>

            {/* button to close pop-up form */}
            <button
              id="button"
              type="button"
              className="btn cancel"
              onClick={closeForm}
            >
              Close
            </button>
          </div>
        </div>
      </form>

      {/*button to open the pop-up form*/}
      <button className="open-button" id="button" onClick={openForm}>
        Open Form
      </button>

      {/* Table component imported */}
      <Table
        details={details}
        setDetails={setDetails}
        editUserId={editUserId}
        setEditUserId={setEditUserId}
      />
    </>
  );
}
