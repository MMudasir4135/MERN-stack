import React from "react";
import '../EditableRow/EditableRow.css';

export default function EditableRow({
  // exported from Table.js
  editFormData,
  handleEditFormChange,
  handleCancelClick,
}) {
  return (
    // table rows to get the edited user details
    <tr>
      <td>
        <input
          className="input1"
          type="text"
          id="fname"
          placeholder="First name"
          name="firstName"
          value={editFormData.firstName}
          onChange={handleEditFormChange}
        ></input>
      </td>
      <td>
        <input
          className="input1"
          type="text"
          id="Sname"
          placeholder="Surname"
          name="surName"
          value={editFormData.surName}
          onChange={handleEditFormChange}
        />
      </td>
      <td>
        <input
          className="input1"
          type="number"
          id="phone"
          placeholder="Phone or mobile number"
          name="phoneNumber"
          value={editFormData.phoneNumber}
          onChange={handleEditFormChange}
        />
      </td>
      <td>
        <input
          className="input1"
          type="text"
          id="Country"
          placeholder="Country"
          name="country"
          value={editFormData.country}
          onChange={handleEditFormChange}
        />
      </td>
      <td>
        <input
          className="input1"
          type="text"
          id="bank"
          placeholder="Back Account"
          name="bankAccount"
          value={editFormData.bankAccount}
          onChange={handleEditFormChange}
        />
      </td>
      <td>
        <input
          className="input1"
          type="text"
          placeholder="Service name"
          name="serviceName"
          id="service"
          value={editFormData.serviceName}
          onChange={handleEditFormChange}
        />
      </td>
      <td>
        <input
          className="input1"
          type="text"
          placeholder="type"
          name="serviceType"
          id="type"
          value={editFormData.serviceType}
          onChange={handleEditFormChange}
        />
      </td>
      <td>
        <input
          className="input1"
          type="number"
          placeholder="Amount"
          name="amount"
          id="amount"
          value={editFormData.amount}
          onChange={handleEditFormChange}
        />
      </td>
      <td>
        {/* button to save edited User */}

        <button type="submit">Save</button>

        {/* button to cancel editing */}

        <button type="button" onClick={handleCancelClick}>
          Cancel
        </button>
      </td>
    </tr>
  );
}
