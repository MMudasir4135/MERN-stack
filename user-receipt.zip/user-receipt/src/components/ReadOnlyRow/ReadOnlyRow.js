import React from "react";
import "../ReadOnlyRow/ReadOnlyRow.css";

export default function ReadOnlyRow({
  //exported from Table.js
  detail,
  handleEditClick,
  handleDeleteClick,
}) {
  return (
    <>
      {/* Table to show user details */}
      <tr>
        <td>{detail.firstName}</td>
        <td>{detail.surName}</td>
        <td>{detail.phoneNumber}</td>
        <td>{detail.country}</td>
        <td>{detail.bankAccount}</td>
        <td>{detail.serviceName}</td>
        <td>{detail.serviceType}</td>
        <td>{detail.amount}</td>
        <td>
          {/* button to edit the user details */}
          <button
            type="button"
            onClick={(event) => handleEditClick(event, detail)}
          >
            Edit
          </button>
          {/* button to delete user from table */}
          <button
            type="button"
            onClick={(event) => handleDeleteClick(event, detail.id)}
          >
            Delete
          </button>
        </td>
      </tr>
    </>
  );
}
