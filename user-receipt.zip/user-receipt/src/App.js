import "./App.css";
import React from "react";
import UserInput from "./components/UserInput/UserInput";

function App() {
  return (
    <>
      <UserInput />
    </>
  );
}

export default App;
