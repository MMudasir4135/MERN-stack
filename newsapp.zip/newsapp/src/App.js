import "./App.css";

import React, { Component } from "react";
import Navbar from "./components/Navbar/Navbar";
import NewsComponent from "./components/NewsComponent/NewsComponent";

export default class App extends Component {
  render() {
    return (
      <div>
        <Navbar />
        <NewsComponent pageSize={9} country="us" apiKey="956da868ebb546b082c81162d2131f37" />
      </div>
    );
  }
}
