import React, { Component } from "react";

export class NewsItem extends Component {
  render() {
    let { title, description, imageUrl, newsUrl } = this.props;
    return (
      <div>
        <div className="card" style={{ width: "18rem" }}>
          <img
            style={{ width: "286px", height: "200px" }}
            src={
              !imageUrl
                ? "https://image.cnbcfm.com/api/v1/image/106788828-1604964906278-gettyimages-1229336423-JAPAN_TRADING.jpeg?v=1667519301&w=1920&h=1080"
                : imageUrl
            }
            className="card-img-top"
            alt="noImage"
          />
          <div className="card-body">
            <h5 className="card-title" style={{ fontSize: "15px" }}>
              {title}...
            </h5>
            <p className="card-text" style={{ fontSize: "14px" }}>
              {description}...
            </p>
            <a
              href={newsUrl}
              target="_blank"
              className="btn btn-sm btn-dark"
              rel="noreferrer"
            >
              Read More
            </a>
          </div>
        </div>
      </div>
    );
  }
}

export default NewsItem;
